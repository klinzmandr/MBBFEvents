-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2016 at 09:34 PM
-- Server version: 5.7.13-0ubuntu0.16.04.2
-- PHP Version: 7.0.8-0ubuntu0.16.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mbbfdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `leaders`
--

DROP TABLE IF EXISTS `leaders`;
CREATE TABLE `leaders` (
  `RowID` int(10) NOT NULL,
  `Active` varchar(5) DEFAULT NULL,
  `FirstName` varchar(20) DEFAULT NULL,
  `LastName` varchar(30) DEFAULT NULL,
  `PrimaryPhone` varchar(20) DEFAULT NULL,
  `SecondaryPhone` varchar(15) DEFAULT NULL,
  `Email` varchar(35) DEFAULT NULL,
  `Notes` text,
  `Address1` varchar(100) DEFAULT NULL,
  `Address2` varchar(100) DEFAULT NULL,
  `City` varchar(20) DEFAULT NULL,
  `State` varchar(5) DEFAULT NULL,
  `Zip` varchar(10) DEFAULT NULL,
  `Bio` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `leaders`
--

INSERT INTO `leaders` (`RowID`, `Active`, `FirstName`, `LastName`, `PrimaryPhone`, `SecondaryPhone`, `Email`, `Notes`, `Address1`, `Address2`, `City`, `State`, `Zip`, `Bio`) VALUES
(1, 'Yes', 'Louise', 'Abbott', '805-534-1490', '805-441-2080', 'labbott@charter.net', NULL, '1748 Los Osos Valley RD.', NULL, 'Los Osos', 'CA', '93402', 'Louise Abbott is a self-proclaimed Silicon Valley escapee. She spent most of her career in the high-tech world, retiring as a program manager for Cisco Systems. Since moving to the Central Coast she has become very active as a State Park Docent, and is a'),
(2, 'Yes', 'Carole', 'Adams', '805-927-5847', NULL, 'pcadams71@sbcglobal.net', NULL, '5050 Oakhurst', NULL, 'Cambria', 'CA', '93428', 'Phil and Carole Adams have been leading Adventure With Nature Walks for California State Parks for over 10 years. They also volunteer with Friends of the Elephant Seal, Monterey Bay National Marine Sanctuary, and Piedras Blancas Light Station. They enjoy '),
(3, 'Yes', 'Phil', 'Adams', '805-927-5847', NULL, 'pcadams71@sbcglobal.net', NULL, '5050 Oakhurst', NULL, 'Cambria', 'CA', '93428', 'Phil and Carole Adams have been leading Adventure With Nature Walks for California State Parks for over 10 years. They also volunteer with Friends of the Elephant Seal, Monterey Bay National Marine Sanctuary, and Piedras Blancas Light Station. They enjoy '),
(4, 'No', 'Mary', 'Adams', '805-474-0147', NULL, 'madams@waterboards.ca.gov', NULL, '6930 Lopez Dr.', NULL, 'Arroyo Grande', 'CA', '93420', NULL),
(5, 'No', 'Larry', 'Allen ', '723-221-2022', NULL, 'larryallen@earlymusicla.org', NULL, '2528 Denton Ave.', NULL, 'Rosemead', 'CA', '91770', NULL),
(6, 'No', 'Paul', 'Andreano', '805-235-6227', NULL, 'himountainpaul@gmail.com', NULL, '1000 Montecito Rd. #3', NULL, 'Cayucos', 'CA', '93430', NULL),
(7, 'Yes', 'Rick', 'Austin', '805-771-9084', '310-4614-8041', 'rcaustin@charter.net ', NULL, '360 Piney Way', NULL, 'Morro Bay', 'CA', '93442', 'Rick is an 8th grade math teacher. He cautiously began birding 40 years ago and has since birded six of the seven continents in search of avian colors, vocalizations, and novel behaviors. He has led tours in Alaska and California, and recently spent thr'),
(8, 'Yes', 'Mike', 'Baird', '805-772-2044', '805-704-2064', 'mike@mikebaird.com', NULL, '2756 Indigo Circle', NULL, 'Morro Bay', 'CA', '93442', 'Mike has been a State Park Docent since 2001 and leads Digital Photowalks (www.photomorrobay.com). He is a PhD Computer Scientist with an MBA, retired from ask.com, and author of Engineering Your Start-up (www.eysu.org). Mike is editor of www.morro-bay.co'),
(9, 'No', 'Bob', 'Barnes', '760-382-1260', NULL, 'bbarnes@lightspeed.net', NULL, '1009 Las Cruces', NULL, 'Ridgecrest', 'CA', '93555', 'Bob Barnes has been birding through California for the past 35 years. His expertise in Southern Sierra species distribution and status is unparalleled. Bob has led over 200 birding tours, and he authored the section on Kern River Valley and Southern Sier'),
(10, 'Yes', 'Dawn', 'Beattie', NULL, NULL, 'Dawn_Beattie@charter.net', NULL, '2760 Indigo Circle', NULL, 'Morro Bay', 'CA', '93442', NULL),
(11, 'Yes', 'Lexi', 'Bell', NULL, '805 242-3551', 'lbell@mbnep.org', NULL, '601 Embarcadero, Suite 11', NULL, 'Morro Bay', 'CA', '93442', 'Lexie Bell is the Assistant Director for the Morro Bay National Estuary Program. Lexie\'s central role is to facilitate the valuable science and conservation work of the organization by helping to establish priorities for the organization, managing adminis'),
(12, 'Yes', 'Louise', 'Bello', '805-748-4969', NULL, 'rxbello@msn.com', NULL, '951 Ridgeway St', NULL, 'Morro Bay', 'CA', '93442', NULL),
(13, 'Yes', 'Randy', 'Bello', '805-748-4969', NULL, 'rxbello@msn.com', NULL, '951 Ridgeway St', NULL, 'Morro Bay', 'CA', '93442', NULL),
(14, 'No', 'Jodee', 'Bennett', NULL, '805-440-5408', 'jbennett@calpoly.edu', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(15, 'Yes', 'Tom', 'Benson', NULL, '909 648-0899', 'tbenson@CSUSB.EDU', NULL, '1250 Kendall Drive Apt 117', NULL, 'San Bernardino', 'CA', '92407', 'San Bernardino, CA 92407'),
(16, 'No', 'Dave', 'Berry', '805-466-6184', NULL, 'gberry@charter.net', NULL, '9125 Santa Barbara Rd/', NULL, 'Atascadero', 'CA', '93422', NULL),
(17, 'Yes', 'Daniel', 'Bohlman', '805-235-2874', NULL, 'danielb@lcslo.org', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(18, 'No', 'Mick', 'Bondello', '805-481-6549', NULL, 'dinonick@hotmail.com', NULL, '207 McKinley St.', NULL, 'Arroyo Grande', 'CA', '93420', NULL),
(19, 'Yes', 'Bill', 'Bouton', '805-543-3761', '805-540-4352', 'boutonbill@gmail.com', NULL, '2221 King Court, #16', NULL, 'San Luis Obispo', 'CA', '93401', 'A retired college biology teacher, Bill has led nature trips to many locations in the USA, and foreign destinations such as Costa Rica, Peru and Ecuador, including the Galapagos Islands. Bill began birding at 11 years of age. He is now heavily involved '),
(20, 'No', 'Dick', 'Boyd', '805 772 3993', '805-748-9749', 'dickboyd@charter.net', NULL, '375 Fresno Ave.', NULL, 'Morro Bay', 'CA', '93442', NULL),
(21, 'No', 'Bryan', 'Brown ', '805-528-8137', NULL, 'bryanlives@sbcglobal.net', NULL, '1871 Fearn', NULL, 'Los Osos', 'CA', '93402', NULL),
(22, 'No', 'Eric', 'Brunschwiler', '805-927-1923', '805-909-9412', 'ebrunsch@ucsc.edu', NULL, NULL, NULL, 'Cambria', 'CA', NULL, NULL),
(23, 'Yes', 'Mike', 'Bush', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'Yes', 'Chris', 'Cameron', NULL, NULL, NULL, NULL, '1670 7th St.', NULL, 'Los Osos', 'CA', '93402', NULL),
(25, 'Yes', 'Jay', 'Carroll', '805-528-6064', '805-235-4573', 'jcarroll@tenera.com', NULL, '141 Suburban Rd., Suite A2', 'Tenera Environmental Inc', 'San Luis Obispo', 'CA', '93401', 'Jay is a marine biologist who has worked as an environmental consultant on the Central Coast for over 35 years. His interest in birds began with shorebird censuses in Elkhorn Slough in the 1970s and later expanded during trips to southeast Alaska, the Gal'),
(26, 'Yes', 'Ralph', 'Cass', '805-528-3292', NULL, 'RalphCass@sbcglobal.net', NULL, '1134 5th St.', NULL, 'Los Osos', 'CA', '93402', NULL),
(27, 'No', 'Ted', 'Chandik', '605-326-1360', NULL, 'flybydawn@yahoo.com', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(28, 'No', 'Jamie', 'Chavez', '805 934-3154', '805-268-5186', 'almiyi@verizon.net  \n \n', NULL, '935 Rainbow Dr.', NULL, 'Santa Maria', 'CA', '93455', NULL),
(29, 'No', 'Vince', 'Cicero', '805-927-2185', NULL, 'vcicero@hearst-castle.org', NULL, 'Hearst Castle,750 H.CastleRd', NULL, 'San Simeon', 'CA', '93452', NULL),
(30, 'Yes', 'Karen', 'Clarke', '805-927-0168', NULL, 'Seachest@charter.net', NULL, '6216 Moonstone Bch Dr', NULL, 'Cambria', 'CA', '93428', 'Karen has been birding since the early 1990s. Besides the birds of the Central Coast, she loves to observe them in exotic places like Borneo, the Philippines, Namibia, and various parts of Alaska. She and her husband live in Cambria, where they have a se'),
(31, 'No', 'Dave', 'Compton', NULL, NULL, 'davcompton@earthlink.net', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(32, 'No', 'Mike', 'Connolly', '805-927-6291', '805-776-2564', 'mconnolly@hearstcastle.com', NULL, '750 Hearst Castle Rd.', 'Coastal Discovery Center', 'San Simeon', 'CA', '93452', NULL),
(33, 'No', 'Joyce', 'Cory', '805-534-9916', NULL, 'docentjoyce@yahoo.com', NULL, '1412 4th St. ', NULL, 'Los Osos', 'CA', '93402', 'Joyce is a volunteer for the California State Parks and active at Montaña de Oro State Park. She is a field trip leader for Easy Birding at the Cloisters Park in Morro Bay. Joyce began birding when she moved to the Central Coast in 1996. Her nature photos'),
(34, 'Yes', 'Van', 'Dees', NULL, NULL, 'vannguyendees@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 'Yes', 'Rick', 'Derevan', '805-416-3799', '805-952-5092', 'rickderevan@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 'No', 'Joe', 'Dickerson', '(805) 693-9534\n', NULL, 'JADPhoto@aol.com', NULL, NULL, NULL, 'Solvang', 'CA', NULL, NULL),
(37, 'Yes', 'Pete', 'Dullea', NULL, '805-350-1304', 'pdullea@hotmail.com', NULL, 'P.O.Box 1415', NULL, 'Buellton', 'CA', '93427', 'Peter Dullea is a retired Deputy Public Defender who has been birding seriously for about 18 years. Peter is a docent at the Sedgwick Ranch Nature Reserve (a University of California research facility), and a docent/volunteer for the Neal Taylor Nature C'),
(38, 'No', 'Kathy', 'Duncan', '805 462-1553', NULL, 'kathyd227@yahoo.com', NULL, 'P. O. Box 787', NULL, 'Morro Bay', 'CA', '93443', NULL),
(39, 'No', 'Jon', 'Dunn', NULL, NULL, 'cerwa@earthlink.net', NULL, '52 Nevada St.', NULL, 'Bishop', 'CA', '93514', NULL),
(40, 'Yes', 'Tom', 'Edell', '805-995-1691', '805-235-0831', 'tedell@aol.com', NULL, '46 8th St.', NULL, 'Cayucos', 'CA', '93430', 'Tom has lived on the Central Coast in Cayucos since 1975, when he came to Cal Poly State University where he obtained a B.S. in Natural Resource Management. Always interested in birds, an ornithology class sparked a passion that continues today. He has b'),
(41, 'Yes', 'Herb', 'Elliott', '805 714 4363', NULL, 'hde@charter.net', NULL, '2350 Florence Ave', NULL, 'San Luis Obispo', 'CA', '93401', NULL),
(42, 'Yes', 'Gary', 'Espiau', '805-934-0999', NULL, 'garyjudy.esp@verizon.net', NULL, '3695 Margie Ave', NULL, 'Santa Maria', 'CA', '93455', NULL),
(43, 'No', 'Rebecca', 'Fay', NULL, '805-710-2319', 'rfay@tcsn.net', NULL, '1140 Iris St. # 3', NULL, 'San Luis Obispo', 'CA', '93401', NULL),
(44, 'No', 'Dave', 'Ficke', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(45, 'No', 'Craig', 'Fiehler', NULL, '661-565-5242', 'kragadox@yahoo.com', NULL, '6815 Lafayette Way\nBakersfield, CA 93309', NULL, 'Bakersfield', 'CA', '93309', NULL),
(46, 'No', 'Bob', 'Field', '773-6644', NULL, 'field64@charter.net', NULL, '64 Whitecap St.', NULL, 'Pismo Beach', 'CA', '93449', NULL),
(47, 'No', 'Shawneen', 'Finnegan', '503-729-1769', NULL, 'Shawneenfinnegan@gmail.com', NULL, '6555 SW Old Scholls Ferry Road Apt 8', NULL, 'Portland', 'OR', '97223', 'Shawneen\'s artistic parents taught her to draw and paint early in life. As a young adult in the early 1980\'s she became obsessed with watching birds. Since then she has worn many hats, including artist/illustrator, tour leader and tour manager for WINGS, '),
(48, 'No', 'Sam', 'Fitton', '513.523.4599 ', '513-314-8469', 'sfitton@woh.rr.com', NULL, '6025 Booth Rd', NULL, 'Oxford', 'CA', NULL, 'Sam Fitton started birding early in life growing up on a farm in southwestern Ohio. His desire to know the local birds led to missed chores but plenty of support from his family. Sam quickly got a dream job as field ornithologist in Wyoming, and for 20 ye'),
(49, 'Yes', 'John', 'Flaherty', '805-528-4333', '805-235-4381', 'john@centralcoastoutdoors.com', NULL, '247 Vista Ct. ', NULL, 'Los Osos', 'CA', '93403', 'John is Central Coast Outdoors owner, 2003 to present, and an outdoor guide since 1991. He currently runs kayak eco-tours on Morro Bay and enthusiastically shares his wealth of knowledge about life in and on the bay, including shorebirds, migrating waterf'),
(50, 'Yes', 'Virginia', 'Flaherty', '805-528-4333', '805-235-4381', 'john@centralcoastoutdoors.com', NULL, '247 Vista Ct.', NULL, 'Los Osos', 'CA', '93403', NULL),
(51, 'No', 'Clinton', 'Francis', '805.756.5358', NULL, 'cdfranci@calpoly.edu', NULL, '1 Grand Ave', 'Cal Poly Biological Sciences', 'San Luis Obispo', 'CA', '93407', NULL),
(52, 'Yes', 'Karl', 'Frank', '360-319-0900', '360-319-0900', 'karlandrobin@gmail.com\n', NULL, '17642 Delano Street', NULL, 'Encino', 'CA', '91316', 'Karl is a Biology teacher in Los Angeles. A friend showed him a Brown creeper and White-headed woodpecker in Sequoia\'s Giant Forest in 1993, and a life-long passion grew from there. Karl has been bird watching in Israel, Sweden, Brazil, Peru, Ecuador, '),
(53, 'Yes', 'Claudia', 'Freitas', '805-460-9022', '805-440-1753', 'cfreitas365@gmail.com', NULL, '12710 Escabroso Ct.', NULL, 'Atascadero', 'CA', '93422', 'Claudia Freitas is a retired Biology professor. After teaching college Zoology, Wildlife Bio, Marine Bio and a variety of Natural History classes including Birding classes, for 33 years she moved back to the central coast where she had gone to college an'),
(54, 'No', 'Wes', 'Fritz', '805-895-0685', '805-895-0685', 'wes-fritz@verizon.net', NULL, 'P.O. Box 1253', NULL, 'Solvang', 'CA', '93464', NULL),
(55, 'No', 'Noah', 'Gaines', NULL, NULL, 'skater_ako1@hotmail.com', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(56, 'Yes', 'Neil', 'Gilbert', '805-772-7273', NULL, 'prairiemerlin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(57, 'No', 'Neil', 'Gilbert', '805-772-7273', NULL, 'prairiemerlin@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 'I am a senior at Calvin College in Grand Rapids, Michigan, double-majoring in biology and Spanish. Birds have fascinated me since the age of six. Apart from birds, I enjoy spying on dragonflies and plants. When I\'m not in the field, an ideal evening would'),
(58, 'No', 'Jesse', 'Grantham', '805-640-9635', NULL, 'jesseg@ojai.net', NULL, '66 Taormina Road', NULL, 'Ojai', 'CA', '93023', NULL),
(59, 'Yes', 'Tom', 'Graves', '805-286-2862', NULL, 'wtkite@sbcglobal.net', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(60, 'No', 'Marlin', 'Greene', '206-784-1641 ', '206.617.6202', 'marlin@3hats.com', NULL, '520115th Ave. NW, Suite 22 ', NULL, 'Seattle', 'CA', NULL, NULL),
(61, 'Yes', 'Steve', 'Griffith', '805-772-7539', '805-215-2256', 'aureolin@hotmail.com', NULL, '655 Paula St', NULL, 'Morro Bay', 'CA', '93442', NULL),
(62, 'Yes', 'Jessica', 'Griffiths', '847-334-1196', NULL, 'jessica.l.griffiths@gmail.com', NULL, '2220 Exposition Dr #76', NULL, 'San Luis Obispo', 'CA', '93401', 'Jessica Griffiths has been working as a field ornithologist for over 10 years. She grew up in Chicago, got her undergrad degree at Wellesley College outside of Boston, and spent the next few years traveling around the country working for non-profits and '),
(63, 'Yes', 'Susan', 'Grimaud', '805- 543-2141', NULL, 'susangpascal@aol.com', NULL, '1545 Wild Rye Way', NULL, 'Arroyo Grande', 'CA', '93420', NULL),
(64, 'Yes', 'Kara', 'Hagedorn', '805-460-6892', '805-369-9539 ', 'karahagedorn@hotmail.com', NULL, '17400 Oak Ave', NULL, 'Atascadero', 'CA', '93422', 'Kara got turned on to birds camping as a kid in Colorado. After completing her degree in Zoology, she worked as an Environmental Educator for NY State Parks. She volunteered at the Cornell Hawk Barn as a raptor rehabilitator and in 1997 adopted Sunshine,'),
(65, 'Yes', 'Rich', 'Hansen', '805-772-2042', '805-441-4448', 'richimages@tcsn.net', NULL, 'PO Box 694', NULL, 'Morro Bay', 'CA', '93443', 'Rich is a retired FDA Microbiologist. He has been a Central Coast resident for the past 30 years, where he was an Audubon board member when Sweet Springs was acquired, and where he has served in several capacities with the BirdFest over the past 15 years'),
(66, 'No', 'George ', 'Hardie', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(67, 'Yes', 'Marlin', 'Harms', '805-772-7607', '805-286-0261', 'marlin93442@gmail.com', NULL, '563 Estero Way', NULL, 'Morro Bay', 'CA', '93442', 'Marlin has been birding for over 30 years, has lived in Morro Bay that entire time, and considers the bay his back yard. He has been a leader in each of the previous winter bird festivals. He has a degree in biology, assisted in research at Mono Lake an'),
(68, 'No', 'Ed', 'Harper', NULL, '916-704-7954', 'calidris@surewest.net', NULL, '4855 Cameron Ranch Drive', NULL, 'Carmichael', 'CA', '95608', NULL),
(69, 'Yes', 'Adrienne', 'Harris', '805-772-3834', NULL, 'aharris@mbnep.org', NULL, '601 Embarcadero, Suite 11', NULL, 'Morro Bay', 'CA', '93442', NULL),
(70, 'No', 'Cynthia', 'Hartley', '805-443-1888', NULL, '1surfbird@gmail.com', NULL, '3189 Hilltop Dr', NULL, 'Ventura', 'CA', '93003', NULL),
(71, 'Yes', 'Steve', 'Hendricks', '805-305-3744', NULL, 'shendric@cuesta.edu', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(72, 'Yes', 'Josh', 'Heptig', '805-215-4125', NULL, 'jheptig@co.slo.ca.us', NULL, '2990 Dairy Creek', NULL, 'San Luis Obispo', 'CA', '93405', NULL),
(73, 'Yes', 'Ken', 'Hillers', '805-756-1481', NULL, 'khillers@calpoly.edu', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(74, 'No', 'Ron', 'Hirst', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(75, 'No', 'Beck', 'Hoban', NULL, NULL, 'b.hoban@verizon.net', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(76, 'No', 'Ken', 'Hollinga', '805-733-2194', NULL, 'hollinga@verizon.net', NULL, '972 Pellham Dr.', NULL, 'Lompoc', 'CA', '93436', NULL),
(77, 'Yes', 'Cher', 'Hollingworth', '805-738-5588', '805-588-0252', 'hollinga@verizon.net', NULL, '414 Coronado Dr.', NULL, 'Lompoc', 'CA', '93438', NULL),
(78, 'No', 'Mark', 'Holmgren', NULL, NULL, 'holmgren@lifesci.ucsb.edu', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(79, 'No', 'Scott', 'Inman', NULL, '805-305-0049', 'scottinslo@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(80, 'No', 'Kathleen', 'Intorf', '805-434-2131', NULL, 'Kintorf@tcsn.net', NULL, 'PO Box 517', NULL, 'Templeton', 'CA', '93465', NULL),
(81, 'Yes', 'Jodi', 'Isaacs', NULL, '805-458-3974', 'Jodi.Isaacs@parks.ca.gov', NULL, '1320 Van Beurden Dr.', 'San Luis Coastal District', 'Los Osos', 'CA', '93402', 'Jodi has worked in the natural resource management field for over 17 years and currently works as an Environmental Scientist for California State Parks in Morro Bay where she dedicates much of her time to habitat conservation and restoration. Since 2005 s'),
(82, 'No', 'David', 'Jaffee', '802-881-8568', NULL, 'djdenali@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, 'For more than 20 years David Jaffe has guided and taught a variety of audiences about our natural world and our connection with it. His childhood interest in natural systems eventually brought him to Evergreen State College where he earned a B.S. in Envir'),
(83, 'Yes', 'Vicky', 'Johnsen', '760-567-1130', NULL, 'schoonermagic@earthlink.com', NULL, '2335 Tierra Drive', NULL, 'Los Osos', 'CA', '93402', NULL),
(84, 'No', 'Garry', 'Johnson', '771-9281, 772-3738', NULL, 'garryjohnson@charter.net', NULL, '1165 Morro Ave.', NULL, 'Morro Bay', 'CA', '93442', NULL),
(85, 'No', 'Oscar', 'Johnson', NULL, NULL, 'henicorhina@yahoo.com', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(86, 'No', 'Andrea', 'Jones', '805-772-1995 ', '805-748-0501', 'savannarum@hotmail.com', NULL, '601 Embarcadero #14', NULL, 'Morro Bay', 'CA', '93442', 'Andrea Jones has been Audubon California\'s Important Bird Areas Program Director since 2006. She has degrees from the University of Massachusetts in Ornithology and Wildlife Conservation. Her thesis research focused on metapopulation dynamics of grasslan'),
(87, 'Yes', 'Bob', 'Keally', '714-534-5965', '714-305-4438', 'BobKeally@aol.com', NULL, '12602 9th St', NULL, 'Garden Grove', 'CA', '92840', NULL),
(88, 'Yes', 'Dave', 'Keeling', '805-771-9727', '805-756-2780', 'dkeeling@calpoly.edu', NULL, '2661 Laurel Ave.', NULL, 'Morro Bay', 'CA', '93442', 'Dave Keeling is a trained chemist who has taught at Cal Poly for 35 years. He has been a serious amateur photographer since high school, with an initial emphasis on landscapes, but drifted and evolved to wildlife, and in the last 15 years to bird photog'),
(89, 'Yes', 'Paul', 'Keller', '805-773-5903', '805-291-0277', 'wrentitpk@verizon.net', NULL, '3922 Mesa Circle Drive', NULL, 'Lompoc', 'CA', '93436', 'For the last 8 years, Paul has been living and birding in northern Santa Barbara County, where he leads field trips. For the previous 9 years, he served the Santa Barbara Audubon Society as Field Trip Chair.'),
(90, 'Yes', 'Melissa', 'Kelly', '805-937-9349', '805-729-8461', 'MKelly@sbparks.org ', NULL, '5182 Surfbird Lane', NULL, 'Guadalupe', 'CA', '93434', NULL),
(91, 'No', 'Kathleen & Tony', 'Kent', '805-239-9010', '805-550-1647', 'kikapoo@charter.net', NULL, 'PO Box 3557', NULL, 'Paso Robles', 'CA', '93447', NULL),
(92, 'Yes', 'Jerry', 'Kirkhart', '805-534-9198', NULL, 'jkirkhart35@gmail.com', NULL, '2350 Inyo', NULL, 'Los Osos', 'CA', '93402', 'Jerry is a State Park Docent for the CCNHA as well as a Pecho Trail Docent and is very active leading various AWN (Adventures With Nature) walks. Those dealing with natural history and his passion for photography include local Flora and Fauna along with '),
(93, 'No', 'Michaela ', 'Koenig', NULL, NULL, 'michaelamkoenig@yahoo.com', NULL, 'Referred by Mike Stiles, no other info', NULL, NULL, NULL, NULL, NULL),
(94, 'Yes', 'Gale', 'Kordowski', '805-924-1354', '805-801-4513', 'gakbirds@yahoo.com', NULL, 'P.O. Box 249', NULL, 'Cambria', 'CA', '93428', 'Gale began to love birds in the mid-70\'s when she purchased her first Lovebird. Then, in the early 90\'s while on a trip to Point Reyes National Seashore, she noticed birds on a rock in the ocean and wondered what they were. This led Gale to buy her firs'),
(95, 'No', 'Tony', 'Krause', '805-782-9234', NULL, 'anthonykrause@sbcglobal.net', NULL, '657 Pismo St.', NULL, 'San Luis Obispo', 'CA', '93401', NULL),
(96, 'Yes', 'Sally', 'Krenn', '805-545-3159', '805-801-0288', 'krenn@charter.net', NULL, '158 Baker Ave', NULL, 'Pismo Beach', 'CA', '93449', 'Sally has lived on the Central Coast since 1972, when she came to Cal Poly to study Biological Sciences. A phycology class from Dr. Shirley Sparling introduced her to the enthralling marine life on our coastline and involved her in marine science research'),
(97, 'Yes', 'David', 'Lawrence', '805-541-0822', '805-459-1709', 'dmlawrence@mac.com', NULL, '1330 Red Brome Pl.', NULL, 'Arroyo Grande', 'CA', '93420', NULL),
(98, 'No', 'John Muir', 'Laws', '415 682-8115', NULL, 'jlaws@calacademy.org', NULL, NULL, NULL, 'San Francisco', 'CA', '94131', NULL),
(99, 'Yes', 'Kingston', 'Leong', '805-544-1024', NULL, 'kleong@calpoly.edu', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(100, 'Yes', 'Ken', 'Levine', '805-489-7323', '805-550-0797', 'gabyken@charter.net', NULL, '1425 Hillcrest Dr.', NULL, 'Arroyo Grande', 'CA', '93420', 'Ken Levine is a retired veterinarian who practiced in Arroyo Grande for 35 years. He is a charter member of San Luis Obispo Botanical Garden, and has been a docent there for 16 years. Two of his favorite things are plants and birds. This has resulted i'),
(101, 'Yes', 'John', 'Lindsey', NULL, NULL, 'jcl5@pge.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(102, 'No', 'Cheryl', 'Lish', '805-481-8945', '408-810-1470', 'cheryl-lish@earthlink.net', NULL, '365 El Sueno', NULL, 'Arroyo Grande', 'CA', NULL, NULL),
(103, 'No', 'Stephanie', 'Little', NULL, '805-610-6229 ', 'stephjoy13@hotmail.com', NULL, 'Snowy Plover Watch', NULL, NULL, 'CA', NULL, NULL),
(104, 'No', 'Burleigh', 'Lockwood', '559-621-5720', NULL, NULL, NULL, '894 West Belmont', NULL, 'Chaffee Zoo Fresno', 'CA', '93728', NULL),
(105, 'No', 'Darwin', 'Long', '805 750-1294', NULL, 'darwin.long@briloon.org', NULL, '604 E Ave.de los Arboles', NULL, 'Thousand Oaks', 'CA', '91360', NULL),
(106, 'No', 'Tom', 'Maloney', NULL, '748-8231', 'tmaloney@tcn.org', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(107, 'Yes', 'Curtis', 'Marantz', '951-534-0918', '951-742-1894', 'alineandcurtis@aol.com', NULL, '1310 Le Conte Dr.', NULL, 'Riverside', 'CA', '92507', NULL),
(108, 'Yes', 'John', 'Marzluff', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(109, 'Yes', 'John', 'McCabe', '805-464-0528', '805-712-3808', 'mccabewest@aol.com', NULL, '10665 San Marcos Rd.', NULL, 'Atascadero', 'CA', '93422', NULL),
(110, 'Yes', 'Steve', 'McMasters', NULL, '805-471-0750', 'smcmasters@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(111, 'Yes', 'Ron', 'Melcer', '916-296-6729', '916-296-6729', 'corvid88@gmail.com ', NULL, NULL, NULL, 'San Luis Obispo', 'CA', NULL, 'Ron is a lifelong birder turned researcher. He currently resides in Sacramento, and is working for the Department of Water Resources to develop a conservation strategy for the river systems of the CA Central Valley. He is also completing graduate work a'),
(112, 'No', 'Chuck', 'Mills', '528-4350', NULL, 'millschuck55@yahoo.com', NULL, '1675 Los Osos Valley Rd., ', NULL, 'Los Osos', 'CA', '93402', NULL),
(113, 'No', 'Jennifer', 'Moonjian', '805-440-8224', NULL, 'jmoonjia@gmail.com', NULL, '355 Foothill Blvd.', NULL, 'San Luis Obispo', 'CA', '93405', NULL),
(114, 'Yes', 'Kyle', 'Nessen', NULL, '818-522-8207', 'kyle.nessen@gmail.com', NULL, '441 Luneta Dr', NULL, 'San Luis Obispo', 'CA', '93405', NULL),
(115, 'Yes', 'Paul', 'O\'Connor', '805-441-7184', NULL, 'pablopaddlerh2o@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(116, 'No', 'Donna', 'O\'Shaughnessey', '895-466-5784', NULL, 'pterodactgal@charter.net', NULL, '13790 San Antonio Road', NULL, 'Atascadero', 'CA', '93422', NULL),
(117, 'No', 'Charlene', 'Odekirk', '805-546-9543', '805-801-2509', 'zoomom@rocketmail.com', NULL, '830 Columbine Ct.', NULL, 'San Luis Obispo', 'CA', '93401', 'Charlene (on the right in blue), formally a teacher and docent at the Santa Barbara Zoo, joined Rosemary as co-walk leader in 2005. She is also a back desk docent and a member of the Exhibit Enhancement Committee.'),
(118, 'No', 'Rosemary', 'Olszewski', '805-772-4298', '805-704-6710', 'joeo558@aol.com', NULL, '2286 Emerald Cir', NULL, 'Morro Bay', 'CA', '93422', 'Rosemary (on the left in blue), formally a consultant, Environment, Safety and Emergency Management with a major international oil company, designed this walk in 2002. She is also a back desk docent at the Morro Bay Natural History Museum and a member of '),
(119, 'Yes', 'Regena', 'Orr', '805-772-6101x15', '805-550-4815', 'regena.orr@parks.ca.gov', NULL, '11 State Park Rd', NULL, 'Morro Bay', 'CA', '93442', 'After earning a BS in Natural Resources Management from Cal Poly San Luis Obispo, Regena began working for California State Parks in 1995. As an Environmental Scientist, she currently manages the Western Snowy Plover program for State Parks in the Morro '),
(120, 'No', 'Peter', 'Orr', '534-2805 x 15', '805-771-1913', 'rorr@hearst-castle.org', NULL, 'CA State Parks, 11 State Park Rd', NULL, 'Morro Bay ', 'CA', '93442', NULL),
(121, 'Yes', 'Rachel', 'Pass', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(122, 'No', 'Dave', 'Pereksta', '805-644-1766x320', NULL, 'pereksta@pacbell.net', NULL, '2493 Portola Rd., Suite B', 'USFWS', 'Ventura', 'CA', '93003', NULL),
(123, 'No', 'Nicole', 'Perreta', NULL, NULL, 'nikihawk@yahoo.com', NULL, 'P.O.Box 33535', NULL, 'San Diego', 'CA', NULL, NULL),
(124, 'Yes', 'Kaaren', 'Perry', '805-771-0161', '714-878-2797', 'surfbird1@att.net', NULL, '461 Estero Ave.', NULL, 'Morro Bay', 'CA', '93442', 'Kaaren Perry has been interested in birds and nature since childhood. She is an avid birder and has birded throughout the United States, Canada, Alaska, France, England, Greece and the Czech Republic. For the past 20 years, Kaaren has enjoyed leading loc'),
(125, 'No', 'Phil', 'Persons', NULL, NULL, 'philper@rain.org', NULL, '3899 Jalama Rd', NULL, 'Lompoc', 'CA', '93436', NULL),
(126, 'Yes', 'Cruz', 'Phillips', '805-245-8331', '805-245-8331', 'cruzitas@aol.com', NULL, 'PO Box 1107', NULL, 'Santa Ynez', 'CA', '93460', NULL),
(127, 'Yes', 'Lucien', 'Plauzoles', NULL, '424-744-0938', 'plauzoles@me.com', NULL, '533 4th St', NULL, 'Santa Monica', 'CA', '90402', NULL),
(128, 'No', 'Henry', 'Pontarelli', '805-534-1493', NULL, 'wisehen@hotmail.com', NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(129, 'Yes', 'Roy', 'Poucher', NULL, '714-588-8220', 'ROPOUCHER@aol.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(130, 'Yes', 'Penny', 'Principe', '528-2499', '805-503-9282', 'princi@charter.net', NULL, '1857 14th Street', NULL, 'Los Osos', 'CA', '93402', NULL),
(131, 'Yes', 'Don', 'Quintana', '805-528-9012', '805-305-4701', 'don@quintanastudios.com', NULL, '1204 16th St', NULL, 'Los Osos', 'CA', '93402', 'Donald Quintana is a Central California Nature and Wildlife Photographer whose family was an early settler in Morro Bay. He finds comfort and renewal by spending time amidst the wonders of the local natural world. His greatest enjoyment comes from capturi'),
(132, 'No', 'Barbara', 'Renshaw', '534-1865', NULL, NULL, NULL, '616 Santa Lucia', NULL, 'Los Osos', 'CA', '93402', NULL),
(133, 'Yes', 'Robbie', 'Revel', '805-752-1040', '818-618-3458', 'robrev@sbcglobal.net', NULL, '1761 Sixth Street', NULL, 'Los Osos', 'CA', '93402', NULL),
(134, 'Yes', 'Bob', 'Revel', '805-752-1040', '818-439-7723', 'bobrevel@sbcglobal.net', NULL, '1761 Sixth St', NULL, 'Los Osos', 'CA', '93402', NULL),
(135, 'No', 'Don', 'Roberson', '831-375-0794', NULL, 'creagus@montereybay.com', NULL, '282 Grove Acre Ave.', NULL, 'Pacific Grove', 'CA', '93950', NULL),
(136, 'No', 'Jeri', 'Roberts', '805-544-8860', NULL, 'Jbenchman@aol.com', NULL, '2700 Perfumo Canyon Rd.', NULL, 'San Luis Obispo', 'CA', '93403', NULL),
(137, 'Yes', 'Dan', 'Robinette', NULL, NULL, 'drobinette@pointblue.org', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(138, 'Yes', 'Michele', 'Roest', '927-3101', NULL, 'michele.roest@sciencecurric.org', NULL, 'P.O. Box 385', NULL, 'Cambria', 'CA', '93428', NULL),
(139, 'No', 'Marilyn', 'Rose', NULL, NULL, 'ootw@mcn.org ', NULL, 'PO Box 1010', 'Out of this World Discount Binoculars', 'Mendocino', 'CA', '95460', NULL),
(140, 'Yes', 'John', 'Roser', '805-528-7912', '805-801-6018', 'rosercomeau@sbcglobal.net', NULL, '309 Biscarth Rd.', NULL, 'Los Osos', 'CA', '93402', NULL),
(141, 'Yes', 'Jim', 'Royer', '805-528-8933', '805-748-7895', 'jrmotmot@gmail.com', NULL, '337 Henrietta Ave.', NULL, 'Los Osos', 'CA', '93402', 'Jim got the bug for birding in the mid 70\'s from his brother Allen, and has led field trips for various Audubon Chapters, the WFO, the ABA, and other groups since the late 70\'s (including trips to Veracruz, Mexico, to see the world\'s largest raptor migrat'),
(142, 'No', 'Ron', 'Ruppert', '805-528-8346', '805-235-9760', 'rruppert@cuessta.edu', NULL, '1197 10th St', NULL, 'Los Osos', 'CA', '93402', 'Ron Ruppert is chair of the biology department at Cuesta College. He also teaches courses in Human Anatomy, Natural History, Life Science and Desert Biology. Ron was first introduced to Osteology (bones) at Chaffey College in Southern California. Transfer'),
(143, 'Yes', 'John', 'Sayers', '805-458-9626', NULL, 'john.sayers@parks.ca.gov', NULL, '1320 Van Beurden Dr.', 'San Luis Coastal District', 'Los Osos', 'CA', '93402', 'Environmental Scientist, California State Parks, San Luis Obispo Coast District since 2005. First started birding in earnest in 2005 while monitoring snowy plover populations along the beaches of San Luis Obispo County. He grew up in southern California'),
(144, 'Yes', 'Ross', 'Schaefer', NULL, '805-975-7120', 'schaeferross@yahoo.com', NULL, '605 Rivera Circle', NULL, 'Nipomo', 'CA', NULL, 'Since the age of 5, Ross Schaefer has had a distinct interest in birds. After moving to the Central Coast and learning from local birder Jim Royer, Ross began leading trips for festivals and other organizations. Now 17, Ross has birded in 5 continents, '),
(145, 'No', 'Alan', 'Schmierer', NULL, '805-801-3701', 'aaschmierer@yahoo.com', NULL, '2554 Canet Rd.', NULL, 'San Luis Obispo', 'CA', '93405', NULL),
(146, 'No', 'John', 'Schmitt', '760-376-6820', NULL, 'norbertraven@yahoo.com', NULL, 'P.O. Box 9', NULL, 'Wofford Heights', 'CA', '93285', NULL),
(147, 'Yes', 'Brad', 'Schram', '805-489-1260', '805-801-9325', 'gonebrdn@lightspeed.net', NULL, '1210 Antler Dr.', NULL, 'Arroyo Grande', 'CA', '93420', 'Brad started birding in the 1940s as a child in the San Bernardino Mountains of Southern California. After retiring early from the business world he has served since 1997 as a part-time birding tour leader for Victor Emanuel Nature Tours and as a natural'),
(148, 'Yes', 'Steve', 'Schubert', '805-528-6138', '805-440-9390', 's_schub1@msn.com ', NULL, 'P.O. Box 6002', NULL, 'Los Osos', 'CA', '93412', 'Steve is an active member of the Morro Coast Audubon Society: President 2000-2001; past Program Chairman; author "The Peregrine Falcons of Morro Rock: A 40-Year History" (www.morrorockperegrines.com); Volunteer Coordinator (1996-present) for the Hi Mount'),
(149, 'No', 'Kathy', 'Sharum', '661-391-6033', '661-391-6033', 'e-mail: ksharum@blm.gov', NULL, '3801 Pegasus Drive', 'Carrizo Plain Nat. Mon. BLM Bakersfield Field Office', 'Bakersfield', 'CA', '93308', NULL),
(150, 'Yes', 'Dennis', 'Sheridan', '805-528-2373', NULL, 'dennissher@sbcglobal.net', NULL, '1321 17th St.', NULL, 'Los Osos', 'CA', '93402', 'Dennis Sheridan is a native Californian who grew up in Arcadia. He graduated from Cal Poly Pomona with a degree in biology, specialty entomology. He moved to Morro Bay in 1974 and began a career in photography, concentrating on birds of prey and native '),
(151, 'Yes', 'Tom', 'Slater', '805-441-6945', NULL, 'tomslaterphotography@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, 'An avid surfer and extreme rock climber for more than 30 years, Tom only recently "discovered" birding in October 2011. A self-starter (inspired by the book and movie "The Big Year"), he bought a Sibley\'s guide and some binoculars and then scoured the Cen'),
(152, 'Yes', 'Owen', 'Slater', '805-441-6945', NULL, 'tomslaterphotography@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(153, 'Yes', 'Greg', 'Smith', '805-441-2169', '805-441-2169', 'slobird@aol.com', NULL, 'P.O. Box 2002', NULL, 'Morro Bay', 'CA', '93443', 'Greg Smith has birded and searched out nature\'s wonders on all seven continents and has led natural history and birding tours in California, Alaska, Argentina, Chile, the Falkland Islands, South Georgia, and Antarctica. He is recently retired after a 27-y'),
(154, 'Yes', 'Maggie', 'Smith', '805-481-9292', '805-710-4356', 'milleniummaggs@charter.net', NULL, '512 LePoint St.', NULL, 'Arroyo Grande', 'CA', '93420', 'Maggie began noticing and identifying birds in 2004. She has led field trips for Morro Coast Audubon Society, Winter Bird Festival and Western Field Ornithologists since 2005. As a volunteer, she\'s helped with a series of Sea Bird surveys for Cal Poly a'),
(155, 'No', 'Kelly', 'Sorenson', '831-455-9514', NULL, 'kellysorenson@ventanaws.org', NULL, 'Ventana Wilderness Soc.', '19045 Portola Dr ', 'Salinas', 'CA', '93908', NULL),
(156, 'No', 'Bob', 'Stafford', '805-528-8670', NULL, 'bstafford@dfg.ca.gov', NULL, 'PO Box 6360', NULL, 'Los Osos', 'CA', '93402', 'Robert Stafford has a worked on a wide array of wildlife species in central California for over 25 years. Research subjects have ranged from black bears, tule elk, and San Joaquin kit foxes to desert tortoises, blunt-nosed leopard lizards, and western p'),
(157, 'No', 'John C.', 'Sterling', '530-908-3836', NULL, NULL, NULL, NULL, NULL, NULL, 'CA', NULL, NULL),
(158, 'Yes', 'Capt.', 'Stew', NULL, '805-217-4146', NULL, NULL, '571 Embarcadero', NULL, 'Morro Bay', 'CA', '93442', NULL),
(159, 'Yes', 'Mike', 'Stiles', '805-528-1515', '805-213-3164', 'mstiles@calpoly.edu', NULL, '1120 13th St.', NULL, 'Los Osos', 'CA', '93402', 'Mike is a local native and has been birding in the area since 1973. He has led trips for Morro Coast Audubon Society and the Winter Bird Festival. He has been a board member for the local Audubon Society for the last 7 years as Field Trip Chair, and as th'),
(160, 'Yes', 'Doug', 'Stinson', '805-459-0861', '805-459-0861', 'dgstinson@yahoo.com', NULL, '3940 Broad St', NULL, 'San Luis Obispo', 'CA', '93401', NULL),
(161, 'Yes', 'Jeanette', 'Stone', '805-462-0643', NULL, 'jstone_tierney@charter.net', NULL, '8685 Casanova Rd.', 'PWC', 'Atascadero', 'CA', '93442', 'Jeanette serves as the Center Operations Director for Pacific Wildlife Care in Morro Bay, CA. She has volunteered with PWC for over 3 years in different capacities; as a center worker, website designer, board vice-president and president. As Center Direc'),
(162, 'Yes', 'Jan', 'Surbey', '805-772-7273', '805-772-7273', 'jansurbey@earthlink.net', NULL, '3346 Tide', NULL, 'Morro Bay', 'CA', '93442', 'Jan has been a Morro Coast Audubon Society Board member 2006 to present (Hospitality, chair, President, Past President). A retired teacher from St. Louis, Missouri, Jan moved to the Central Coast in 1999 to enjoy year-round running. Even after traveling'),
(163, 'No', 'Linda', 'Tanner', '805-534-9919', '550-5777', 'goingslo@yahoo.com', NULL, '556 Mar Vista Dr. ', NULL, 'Los Osos', 'CA', '93402', NULL),
(164, 'Yes', 'Bill', 'Taylor', NULL, '715-546-2207', 'wht3lks@newnorth.net', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(165, 'Yes', 'Dean', 'Thompson', '805- 528-8504', '805-215-4518', 'ososclan@sbcglobal.net', NULL, '1115 17th St.', NULL, 'Los Osos', 'CA', '93402', 'Dean Thompson is a naturalist who also happens to enjoy birding. Trained as a wildlife biologist, he has worked with a variety of raptors in California, Arizona and Wyoming for The Peregrine Fund and the Santa Cruz Predatory Bird Group. He traveled to A'),
(166, 'No', 'Guy', 'Tingos', '805-801-4878', NULL, 'guy.tingos@cox.net', NULL, NULL, NULL, 'Santa Barbara', 'CA', NULL, NULL),
(167, 'No', 'Nick', 'Todd', '805-801-4878', NULL, 'jnicktodd@gmail.com ', NULL, '1541 Gamby Way', NULL, 'Solvang', 'CA', '93463', NULL),
(168, 'Yes', 'Bert', 'Townsend', '805-543-1373', '805-748-4380', 'betownsend@sbcglobal.net', NULL, '531 Lawrence Dr.', NULL, 'San Luis Obispo', 'CA', '93401', 'Bert Townsend has been birding since age 11, including several area of North America; from Michigan to Florida and California to Texas. He has also birded in Central America and Europe. Bert has been anticipating in the MBWBF from the beginning.'),
(169, 'Yes', 'George', 'Trevelyan', NULL, '805-471-9683', 'gtrevelyan@sbcglobal.net', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(170, 'No', 'Mike', 'Tyner', '805-234-0320', NULL, 'mtyner@charter.net', NULL, '909 Torrey Pines Dr.', NULL, 'Paso Robles', 'CA', '93446', NULL),
(171, 'Yes', 'Ray', 'VanBuskirk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(172, 'Yes', 'Art', 'Vandenhueval', '805-995-3645  ', NULL, 'kellylvandenheuvel@gmail.com', NULL, '1960 Montecito Rd', NULL, 'Cayucos', 'CA', '93430', NULL),
(173, 'Yes', 'Kelly', 'Vandenhueval', '805-995-3645  ', NULL, 'kellylvandenheuvel@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(174, 'No', 'Francis', 'Villablanca', '756-2200', NULL, 'fvillabl@calpoly.edu', NULL, NULL, 'Dept of Biology, Cal Poly University', NULL, 'CA', NULL, NULL),
(175, 'Yes', 'Karen', 'Watts', '805-772-8396', '805-772-9386', 'klwatts2@charter.net', NULL, '360 Rennell St', NULL, 'Morro Bay', 'CA', '93442', 'Karen Watts has a bachelor\'s degree in Biology from UCSB and a master\'s degree in science education from Cal State East Bay. She is a former molecular biologist and high school science teacher. She has been a docent at the Morro Bay Museum of Natural Hi'),
(176, 'Yes', 'Bruce', 'Webb', '916-768-7940', NULL, 'bruwebb@surewest.net', NULL, 'P. O. BOX 2845', NULL, 'Granite Bay', 'CA', '95746', NULL),
(177, 'Yes', 'Kyle', 'Weichert', '805-235-1133', NULL, 'kyle.weichert@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(178, 'No', 'Scott', 'Weidensaul', NULL, NULL, '​scottweidensaul@verizon.net', NULL, '778 Schwartz Valley Rd', NULL, 'Schuylkill Haven', 'PA', '17972', NULL),
(179, 'No', 'Joel', 'Weiss', NULL, '805-801-6236', 'joelweiss@msn.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(180, 'Yes', 'Dean', 'Wendt', NULL, '805-550-6690', 'dwendt@calpoly.edu', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(181, 'Yes', 'Ray', 'Weymann', NULL, '650-288-1543', 'raywey@charter.net', NULL, '7610 San Marcos Rd', NULL, 'Atascadero', 'CA', '93422', NULL),
(182, 'Yes', 'Eric', 'Wier', '805-543-8769', NULL, 'franknwier@gmail.com', NULL, '1700 San Luis Dr.', NULL, 'San Luis Obispo', 'CA', '93401', NULL),
(183, 'No', 'Pacific', 'Wildlife Care', '805-543-9453', NULL, 'kathyd227@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(184, 'No', 'Sherrie', 'Williamson', NULL, NULL, 'sabo@sabo.org', NULL, NULL, NULL, NULL, NULL, NULL, 'After more than 20 years of general birding and hawkwatching, Sheri L. Williamson’s life got hijacked by hummingbirds when she and her husband and colleague Tom Wood moved to Arizona to manage The Nature Conservancy’s Ramsey Canyon Preserve. A quarter cen'),
(185, 'No', 'Dave', 'Wilson', '805-466-4550', NULL, 'Info@CoyoteRoadSchool.com', NULL, '4255 Lobos Ave.', NULL, 'Atascadero', 'CA', '93422', NULL),
(186, 'No', 'Kevin', 'Winfield', '805-748-2201', NULL, 'subseatours@charter.net', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(187, 'No', 'Tom', 'Wood', NULL, NULL, 'sabo@sabo.org', NULL, NULL, NULL, NULL, NULL, NULL, 'Tom Wood is co-founder of the Southeastern Arizona Bird Observatory, a non-profit conservation organization. A native Texan, he has a B.S. in Wildlife Biology and was director of the Fort Worth Nature Center and Refuge for 14 years before moving to Arizon'),
(188, 'Yes', 'Chuck', 'Woodard', '805-438-3045', '805-704-9835', 'woodard@live.com', NULL, '4695 Santa Margarita Lake Rd', NULL, 'Santa Margarita', 'CA', '93453', 'Chuck is the resident park ranger at Santa Margarita Lake for the County of San Luis Obispo and has been birding the Central Coast since 1986, when he came to Cal Poly SLO and obtained a B.S. in Natural Resource Management. He has done waterfowl and shore'),
(189, 'No', 'Aurianna', 'Woodson', '202-9724 cell', '602-6674 work', 'auriannaw@gmail.com', NULL, ' 1200 Oceanaire Dr Apt A', NULL, 'San Luis Obispo ', 'CA', '93405', NULL),
(190, 'No', 'Jean Pierre', 'Woolf', '905-781-0448', NULL, 'jp.wolff@wolffvineyards.com', NULL, NULL, NULL, 'San Luis Obispo', 'CA', '93401', NULL),
(191, 'No', 'Jim', 'Woolf', '805-439-0540', '805-439-0540', 'slowoolf@gmail.com', NULL, NULL, NULL, 'San Luis Obispo', 'CA', NULL, NULL),
(192, 'Yes', 'Mitch', 'Wyss', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(193, 'Yes', 'Roger', 'Zachary', '805-466-6222', '805-458-8838', 'rzachary@charter.net', NULL, '1800 Traffic Way', NULL, 'Atascadero', 'CA', '93422', 'Roger is a recently retired Biology teacher and former North Cuesta Audubon President and Field-trip Leader. He has been a compiler of the Carrizo Plain CBC since 1983 and is presently an active field-trip leader for Morro Coast Audubon Society and enjo'),
(194, 'Yes', 'Rouvaishyana', NULL, '805-772-2694x105', '805-459-7061', 'Rouvaishyana@parks.ca.gov', NULL, 'Museum of Nat\'l History', NULL, 'Morro Bay', 'CA', '93442', 'Manager, Morro Bay Museum of Natural History since 2005, State Park Interpreter since 1989. Bird Festival program committee member or co-chair since 2006. Morro Coast Audubon Society program co-chair since 2006. Birding informally since childhood, he b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leaders`
--
ALTER TABLE `leaders`
  ADD PRIMARY KEY (`RowID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leaders`
--
ALTER TABLE `leaders`
  MODIFY `RowID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
